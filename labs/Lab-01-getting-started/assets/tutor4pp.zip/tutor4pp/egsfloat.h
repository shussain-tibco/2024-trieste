typedef double EGS_Float;

